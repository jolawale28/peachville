// ignore: unused_import
import 'dart:developer';
import 'package:flutter/material.dart';
// ignore: import_of_legacy_library_into_null_safe
import 'package:webview_flutter/webview_flutter.dart';

final webViewKey = GlobalKey<WebViewContainerState>();

class WebViewPage extends StatefulWidget {
  const WebViewPage(
      {Key? key, required String title, required String selectedUrl})
      : super(key: key);

  @override
  WebViewPageState createState() => WebViewPageState();
}

class WebViewPageState extends State<WebViewPage> {
  bool isLoading = true;
  final _key = UniqueKey();

  bool toggle = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Peachville Portal"),
        actions: <Widget>[
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              // using currentState with question mark to ensure it's not null
              setState(() {
                isLoading = true;
              });
              webViewKey.currentState?.reloadWebView();
            },
          )
        ],
      ),
      // body: WebViewContainer(key: webViewKey),
      body: Stack(
        children: <Widget>[
          WebView(
            key: _key,
            initialUrl: "https://peachvilleplatinum.com/portal/auth/sign_in",
            javascriptMode: JavascriptMode.unrestricted,
            onPageFinished: (finish) {
              setState(() {
                isLoading = false;
              });
            },
          ),
          isLoading
              ? const Center(
                  child: CircularProgressIndicator(),
                )
              : Stack(),
        ],
      ),
    );
  }
}

class WebViewContainer extends StatefulWidget {
  const WebViewContainer({required Key key}) : super(key: key);

  @override
  WebViewContainerState createState() => WebViewContainerState();
}

class WebViewContainerState extends State<WebViewContainer> {
  late WebViewController _webViewController;

  @override
  Widget build(BuildContext context) {
    return WebView(
      onWebViewCreated: (controller) {
        _webViewController = controller;
      },
      initialUrl: "https://peachvilleplatinum.com/portal/auth/sign_in",
    );
  }

  void reloadWebView() {
    _webViewController.reload();
  }
}
