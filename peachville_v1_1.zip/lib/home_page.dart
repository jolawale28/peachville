import 'package:flutter/material.dart';
import 'my_webview_2.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
        body: WebViewPage(
      title: "Peachville Access Portal::Home",
      selectedUrl: "https://peachvilleplatinum.com/portal/auth/sign_in",
    ));
  }
}
